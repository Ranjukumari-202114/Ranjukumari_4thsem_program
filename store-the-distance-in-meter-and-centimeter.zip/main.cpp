/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class DB;
class DM
{
    // declare data member or variables
    float meter, centi;

public:
    void getdata()   
    {
        //Function for getting input  from user
        cout << "\nEnter the distance in(meter-centimeter):";
        cin >> meter >> centi;
    }
    void display()
    {
        //Function for printing output
        cout << "\nThe distance is:";
        cout << meter << " meters and " << centi << " centimeter";
    }
    friend void add(DM &, DB &);
};
class DB
{
    // declare data member or variables
    float inch, feet;

public:
    void getdata()
    {
        //Function for getting input  from user
        cout << "\nEnter the distance in(feet-inch):";
        cin >> feet >> inch;
    }
    void display()
    {
        //Function for displaying the result 
        cout << "\nThe distance is:";
        cout << feet << " feet and " << inch << " inch";
    }
    friend void add(DM &, DB &);
};
void add(DM &a, DB &b)
{
    int role;
    cout << "\nPress 1 for meter-centi:";
    cout << "\nPress 2 for feet-inch:";
    cout << "\nEnter your choice:";
    cin >> role;
    if (role == 1)
    {
        DM d;
        int c = (a.meter * 100 + a.centi + b.feet * 30.48 + b.inch * 2.54);
        if (c >= 100)
        {
            d.meter = c / 100;
            d.centi = c % 100;
        }
        else
        {
            d.meter = 0;
            d.centi = c;
        }
        d.display();
    }
    else
    {
        DB d;
        int i = (a.meter * 39.37 + a.centi * .3937008 + b.feet * 12 + b.inch);
        if (i >= 12)
        {
            d.feet = i / 12;
            d.inch = i % 12;
        }
        else
        {
            d.feet = 0;
            d.inch = i;
        }
        d.display();
    }
}
int main()
{

    DM a;
    DB b;
    a.getdata();
    b.getdata();
    add(a, b);
}